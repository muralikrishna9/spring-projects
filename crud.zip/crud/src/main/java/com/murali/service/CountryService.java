package com.murali.service;

import java.util.List;

import com.murali.model.Country;

public interface CountryService {
    List<Country> listOfCountries();
}

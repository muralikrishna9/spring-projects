package com.murali.dao;

import java.util.List;

import com.murali.model.Country;


public interface CountryDAO {
    List<Country> listOfCountry();
}

package com.murali.dao;

import java.util.List;

import com.murali.model.Organization;

public interface OrganizationDAO {
    List<Organization> listOfOrganizations();
    void editOrganization(Organization organization);
    void addOrganization(Organization organization);
    void removeOrganization(int id);
    Organization getOrganization(int id);
}


package com.myorg.model;

public class Message {

    private String name; // variable contains data by itself or assigned by calling program
    private String text; // variable can also contain data received from database table

    public Message() {}

    public Message(String name, String text) {
        this.name = name;
        this.text = text;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
